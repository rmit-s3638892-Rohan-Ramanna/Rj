package RJ_Game;

import java.util.Scanner;

public class Ozlympic {
	
 	public static void main(String[] args) {
		MenuDriven menu = new MenuDriven ();
		menu.displayMenu();

	    }
}
