package RJ_Game;

import java.util.ArrayList;
import java.util.Scanner;

public class SportsMenu {

	private String cycling;
    private Scanner scan;
    private String running;
    private String swimming;
     	 	 
    
}


