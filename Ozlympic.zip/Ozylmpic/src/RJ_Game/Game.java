package RJ_Game;

public interface Game {
	
	public int minTime();
	public int maxTime();

}
