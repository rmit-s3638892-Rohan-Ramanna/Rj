package RJ_Game;



import java.awt.RenderingHints.Key;
import java.util.*;


public class Data {

	public static HashMap<String,Person> info = new HashMap<String,Person>();
	Set<String> keys = info.keySet();
	public static HashMap<String,String> input = new HashMap<String,String>();



	public void athleteData(){	


		info.put("S11",new Person("S11","Neil","Swimming",21,"TAS"));
		info.put("S22",new Person("S22","Mark","Swimming",29,"SA"));
		info.put("S33",new Person("S33","Steve","Swimming",25,"WA"));
		info.put("S44",new Person("S44","Nicolas","Swimming",28,"QLD"));
		info.put("S55",new Person("S55","Rogue","Swimming",31,"VIC"));
		info.put("S66",new Person("S66","Austin","Swimming",24,"NSW"));
		info.put("S77",new Person("S77","James","Swimming",23,"NSW"));
		info.put("S88",new Person("S88","Jim","Swimming",23,"NSW"));

		info.put("C11",new Person("C11","Roma","Cycling ",21,"TAS"));
		info.put("C22",new Person("C22","Susan","Cycling ",29,"ACT"));
		info.put("C33",new Person("C33","Giri","Cycling ",25,"WA"));
		info.put("C44",new Person("C44","Nargis","Cycling ",28,"QLD"));
		info.put("C55",new Person("C55","Rachele","Cycling ",99,"VIC"));
		info.put("C66",new Person("C66","Amy","Cycling ",24,"NSW"));
		info.put("C77",new Person("C77","Bond","Cycling ",24,"NSW"));
		info.put("C88",new Person("C88","Amy","Cycling ",24,"NSW"));

		info.put("R99",new Person("R99","Naresh","Running ",18,"NT"));
		info.put("R88",new Person("R88","Satya","Running ",21,"WA"));
		info.put("R77",new Person("R77","Shreya","Running ",30,"ACT"));
		info.put("R66",new Person("R66","Dave","Running ",17,"TAS"));
		info.put("R33",new Person("R33","Niraj","Running ",22,"NSW"));
		info.put("R44",new Person("R44","Shivang","Running ",23,"QLD"));
		info.put("R11",new Person("R11","Gagan","Running ",28,"VIC"));	

		info.put("SA01",new Person("SA01","Rohan","SpAthlete ",21,"MYS"));
		info.put("SA02",new Person("SA02","Arjun","SpAthlete ",25,"NSW"));
		info.put("SA03",new Person("SA03","Jimmy","SpAthlete ",48,"NT"));
		info.put("SA04",new Person("SA04","Nilema","SpAthlete ",56,"WA"));
		info.put("SA05",new Person("SA05","Pandeji","SpAthlete ",65,"VIC"));
		info.put("SA07",new Person("SA06","Giri","SpAthlete ",25,"NSW"));

	}

	public static void SelectAthlete(){

		boolean choice = true;
		int p=0;
		String id;

		Scanner scan = new Scanner(System.in);
		System.out.println();


		do{

			System.out.println();
			System.out.println("\tEnter the number of Participants you want to Compete");
			p=scan.nextInt();
			System.out.println("\tYou have Decided to compete with" +" " + p + " " +"Athletes");
			
			if(p>=5 && p<=8){
				System.out.println("\n\tEnter the Athlete ID :	");
				for (int i=0;i<p;i++){
					id = scan.next();
					input.put(id, id);
				}

				for (String key:info.keySet()){
					if (input.keySet().contains(key)){
						System.out.println(info.get(key));
						}
				}
				choice = false;
			}else{
				System.out.println("\n\tHowever You need to have atleast 5 Athletes or atmost 8 Athletes to Start a game.");
				p=scan.nextInt();
			}	
		}while(choice);
	}


	public void addAthlete(String sport, int count ){

		int n = count;
		int c= 1;
		if (sport == "Running"){
			info.clear();
			for (String info : Data.info.keySet() )
				if (input.get(sport).equals("Running") ||input.get(sport).equals("SpAthlete")){
					if (c<=count){
						input.containsValue(sport);
						c++;
					}

				}

		}
	}
	
}






