package RJ_Game;

public class Running {

	private double runstart = 0;
	private double runend = 0;
	
	
	
	
	
}
